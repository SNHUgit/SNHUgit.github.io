package edu.snhu.BriceCreager.Contact;

import java.util.ArrayList;
import java.util.List;

public class ContactService {
	
//	The contact service shall be able to add contacts with a unique ID.
//	The contact service shall be able to delete contacts per contact ID.
//	The contact service shall be able to update contact fields per contact ID. The following fields are updatable:
//		firstName
//		lastName
//		Number
//		Address
	
	private List<Contact> contacts;
		
	public ContactService() {
		contacts = new ArrayList<>();
	}

	public void add(Contact newContact) {
		
		boolean isDuplicate = false;
		
		for (Contact contact : contacts) {
			if(contact.getId().equals(newContact.getId())) {
				isDuplicate = true;
				break;
			}
		}
		
		if (isDuplicate) {
			throw new IllegalArgumentException("Cannot add contact with duplicate id: " + newContact.getId());
		}
		
		contacts.add(newContact);
		
	}
	
	public void delete(String id) {
	    for (int i = 0; i < contacts.size(); i++) {
	        if (contacts.get(i).getId().equals(id)) {
	            contacts.remove(i);
	            return; 
	        }
	    }
	    //moved below to get method
	    //throw new IllegalArgumentException("Contact with ID " + id + " not found.");
	}
	
	

	public Contact get(String id) { 

		Contact foundContact = null;
		
		for(Contact contact: contacts) {
			if (contact.getId().equals(id)) {
				foundContact = contact;
				break;
			}
		}
		
		if (foundContact == null) {
	        throw new IllegalArgumentException("Contact with ID " + id + " not found.");
	    }
		
		return new Contact(foundContact);
		
	}

	public void updateFirstName(String id, String firstName) {
	    for (Contact contact : contacts) {
	        if (contact.getId().equals(id)) {
	            contact.setFirstName(firstName);
	            return;
	        }
	    }
		
	}

	public void updateLastName(String id, String LastName) {
	    for (Contact contact : contacts) {
	        if (contact.getId().equals(id)) {
	            contact.setLastName(LastName);
	            return;
	        }
	    }
		
	}

	public void updateAddress(String id, String address) {
	    for (Contact contact : contacts) {
	        if (contact.getId().equals(id)) {
	            contact.setAddress(address);
	            return;
	        }
	    }
	    
	}
	public void updateNumber(String id, String number) {
	    for (Contact contact : contacts) {
	        if (contact.getId().equals(id)) {
	            contact.setNumber(number);
	            return;
	        }
	    }
	    
	}    
	
}
