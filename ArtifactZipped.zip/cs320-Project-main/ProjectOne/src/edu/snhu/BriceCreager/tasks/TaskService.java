package edu.snhu.BriceCreager.tasks;

import java.util.ArrayList;
import java.util.List;

//Task Service Requirements

//The task service shall be able to add tasks with a unique ID.
//The task service shall be able to delete tasks per task ID.
//The task service shall be able to update task fields per task ID. The following fields are updatable:
	//Name
	//Description

public class TaskService {

	private List<Task> tasks;
	
	public TaskService() { 
		tasks = new ArrayList<>();
	}
	
	public void add(Task newTask) {
		
		boolean isDuplicate = false;
		
		for (Task task : tasks) {
			if(task.getId().equals(newTask.getId())) {
				isDuplicate = true;
				break;
			}
		}
		if (isDuplicate) {
			throw new IllegalArgumentException("Cannot add task with duplicate id: " + newTask.getId());
		}
		tasks.add(newTask);
	}
	
	public void delete(String id) {
	    for (int i = 0; i < tasks.size(); i++) {
	        if (tasks.get(i).getId().equals(id)) {
	        	tasks.remove(i);
	            return; 
	        }
	    }
	}
	
	public void updateName(String id, String name) {
	    for (Task task : tasks) {
	        if (task.getId().equals(id)) {
	            task.setName(name);
	            return;
	        }
	    }
	}
	
	public void updateDescription(String id, String description) {
	    for (Task task : tasks) {
	        if (task.getId().equals(id)) {
	            task.setDescription(description);
	            return;
	        }
	    }
	}
	
	
	public Task get(String id) {
		Task foundTask = null;
		
		for(Task task: tasks) {
			if (task.getId().equals(id)) {
				foundTask = task;
				break;
			}
		}
		
		if (foundTask == null) {
	        throw new IllegalArgumentException("Task with ID " + id + " not found.");
	    }
		
		return new Task(foundTask);
	}
}
