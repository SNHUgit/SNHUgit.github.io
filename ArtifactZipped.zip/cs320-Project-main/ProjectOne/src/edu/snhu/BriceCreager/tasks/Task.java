package edu.snhu.BriceCreager.tasks;

import lombok.EqualsAndHashCode;

//Task Class Requirements

//The task object shall have a required unique task ID String that cannot be longer than 10 characters. The task ID shall not be null and shall not be updatable.
//The task object shall have a required name String field that cannot be longer than 20 characters. The name field shall not be null.
//The task object shall have a required description String field that cannot be longer than 50 characters. The description field shall not be null.

@EqualsAndHashCode
public class Task {

	private String id;
	private String name;
	private String description;
	
	public Task(String id, String name, String description) { 
		super();
		setId(id);
		setName(name);
		setDescription(description);
	}
	
	public String getId() {
		return id;
	}

	private void setId(String id) {
		if (id == null) {
			throw new IllegalArgumentException("id cannot be null");
		}else if (id.length() > 10) {
			throw new IllegalArgumentException("id cannon exceed 10 characters");
		}else if (id.isEmpty()) {
			throw new IllegalArgumentException("id cannot have no characters");
		}
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		if (name == null) {
			throw new IllegalArgumentException("Name cannot be null");
		}else if (name.length() > 20) {
			throw new IllegalArgumentException("Name cannot exceed 20 characters");
		}else if (name.isEmpty()) {
			throw new IllegalArgumentException("Name cannot have no characters");
		}
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		if (description == null) {
			throw new IllegalArgumentException("description cannot be null");
		}else if (description.length() > 50) {
			throw new IllegalArgumentException("description cannot exceed 50 characters");
		}else if (description.isEmpty()) {
			throw new IllegalArgumentException("description cannot have no characters");
		}
		this.description = description;
	}
	
	public Task(Task other) {
		this(other.id,other.name, other.description);
	}
	

}
